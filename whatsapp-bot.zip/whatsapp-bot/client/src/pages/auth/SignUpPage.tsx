import SignUpForm from '../../components/forms/users/SignUpForm'

function SignUpPage() {
    return (
        <SignUpForm />
    )
}

export default SignUpPage