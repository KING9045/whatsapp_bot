import React from 'react'
import LoginForm from '../../components/forms/users/LoginForm'

function LoginPage() {
  return (
    <LoginForm />
  )
}

export default LoginPage