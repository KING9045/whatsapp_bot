export type BackendError = {
    response: { data: { message: string } }
}