import UpdatePasswordForm from '../../components/forms/users/UpdatePasswordForm'

function UpdatePassword() {
  return (
    <UpdatePasswordForm />
  )
}

export default UpdatePassword