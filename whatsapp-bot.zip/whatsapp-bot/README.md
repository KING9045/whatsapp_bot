# whatsap web bot for everry mobile

env variables
NODE_ENV="development"
HOST=https://localhost
PORT=5000
DB_URL=mongodb+srv://username:password@cluster0.pz9ze.mongodb.net/bot?retryWrites=true&w=majority
TZ=Asia/Kolkata
EMAIL_HOST=smptp.gmail.com
EMAIL_PORT= 587
EMAIL_SERVICE=gmail
APP_EMAIL=******@gmail.com
APP_EMAIL_PASSWORD=dyxknkpxemsqqgrbpoh

![Screenshot from 2023-07-09 21-08-54](https://github.com/kumarnishu/whatsapp-bot/assets/45355788/477f3391-8816-4c59-bf56-aadcc35b0d29)
